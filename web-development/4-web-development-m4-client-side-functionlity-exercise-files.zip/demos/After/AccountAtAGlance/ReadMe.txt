This project contains the final source code for the Account at a Glance application.

You'll need:

1. Visual Studio 2010 with SP1
2. SQL Server 2008 Express or Developer (or higher)

To get the database in place, run the AccountsAtAGlance.exe file included in this folder
and define your database name. After running the wizard the database will be created
for you. You may need to update the connection string if you're not using local or .
for the name of the database. You'll find the connection string in web.config.