﻿using System.Collections.Generic;

namespace AccountsAtAGlance.Model
{
    public partial class Security
    {
        public List<SecurityDataPoint> DataPoints { get; set; } 
    }
}
