namespace AccountAtAGlance.Model
{
    public class Exchange
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
