using System.Collections.Generic;

namespace AccountAtAGlance.Model
{
    public abstract class Security
    {
 
    }
}
