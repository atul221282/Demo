﻿using System;
using System.Collections.Generic;

namespace AccountAtAGlance.Model
{
    public class MarketsAndNews
    {
        public List<TickerQuote> Markets { get; set; }
        public List<string> News { get; set; }
    }
}
