namespace AccountAtAGlance.Model
{
    public class MutualFund : Security
    {
        public int MorningStarRating { get; set; }
    }
}
